# Muggles-PA5-COS221
## Members
- u19025492 - Miss. Yashvitha Kanaparthy
- u20665777 - Mr. Tiyego Khoza (Owner)
- u20776340 - Mr. Mishaelin Naidoo
- u20543043 - Ms. Apinda Tekula
- u20450207 - Miss. Sovaria Naidu 

Group project for COS 221 that is due in the 8th of June.

# checklist
***This is a list of items to complete***

## Testing formats
- ~~After you're done making whatever, do this~~
- When you're doing a Task make sure to add your name in brackets at the end (mito)
- ~~Send over your files to this github respository
Cancel changes
# Research(Apinda)
- ~~General overview  and explanation~~
- ~~Team or single sport explained~~
-~~Actions~~
- ~~Location/Date/Time~~
- ~~Sport structure e.g. federation/regions/teams/players~~

# (E)ER-diagram (Yashvitha, Sovaria, Mishaelin)
- Entities and Attributes
- Complex and Derived Attributes
- Relationships and cardinality

# Mapping (Yashvitha, Sovaria, Mishaelin)
- Regular Entity Types
- Weak Entity Types
- 1:1 Relationships
- 1:N Relationships
- M:N Relationships
- Multivalued Attributes
- N-ary Realtionships
- Specialisation and Generalisation
- Unions
- Correctness

# Relation Exclusion (Yashvitha, Mishaelin)
- Visual
- Primary, Secondary and Foreign keys
- Constraints
- Types and constraints (e.g. mullable, length) if applicable
- Checks on applicable fields
- Correctness

# Web Management (Tiyego, Sovaria)
- Player Management
- Sport Heirarchy Management
- Media Management
- Score Management
- Statistics Query

# Sample Data (Tiyego)
- Explanation
- Script/Manual Data Entry
- Data

# Analyse and Optimise (Tiyego, Mishaelin)
- Explanation
- Optimsation
- Interpretation

# Development (Tiyego, Sovaria, Yashvitha, Apinda, Mishaelin)
- Git usage
- README
- Overall quality and impression

# Demo
# Group Cohesion
