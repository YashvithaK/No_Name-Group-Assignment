
<div class="w3-container" style="background-color: red; opacity: 70%;">
    <p>Made with &#x1F499; by the Muggles for COS 221</p>
</div>
