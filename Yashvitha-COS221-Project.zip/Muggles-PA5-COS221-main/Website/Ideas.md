Ideas for a tournment:
- Year of tournmanet
- Scores
- 
Ideas for Team matches:
- Date
- Venue

Ideas for Venue:
- Place