<?php
// Basic connection settings
$db_hostname = 'localhost:3307';
$db_username = 'root';
$db_password = '@Nikito1234';
$db_name = 'sportsdb';

?>